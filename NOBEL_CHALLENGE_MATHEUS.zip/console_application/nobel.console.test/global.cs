global using Microsoft.Extensions.Configuration;
global using nobel.console.test.services;
global using Newtonsoft.Json;