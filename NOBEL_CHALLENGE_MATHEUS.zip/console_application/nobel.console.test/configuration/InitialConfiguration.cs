namespace nobel.console.test.configuration;
public class InitialConfiguration
{

}